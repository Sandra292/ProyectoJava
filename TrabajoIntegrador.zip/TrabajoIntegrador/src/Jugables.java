
public interface Jugables {
	public void jugar();
		
	}

