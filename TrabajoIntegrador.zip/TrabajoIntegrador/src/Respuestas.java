
public class Respuestas implements Jugables {

	public void jugar() {
	System.out.println("Generando la primer respuesta");
	}

	@Override
	public String toString() {
		return "Respuestas []";
	}
	
	

}
